<?php
class bkf_Exception extends Exception{
	function __construct($message) {
		$this->message	=	$message;
	}

}
?>
